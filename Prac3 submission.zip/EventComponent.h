#ifndef EVENTCOMPONENT_H
#define EVENTCOMPONENT_H

#include <string>

/**
 * @brief Common abstraction for every item in the EventFlow Composite tree.
 *
 * GoF Composite Component role. Clients can operate on a leaf or a complete
 * event group through the same interface.
 */
class EventComponent {
public:
    /** @brief Virtual destructor required for polymorphic deletion. */
    virtual ~EventComponent() {}

    /** @brief Opens this component. */
    virtual void open() = 0;

    /** @brief Closes this component. */
    virtual void close() = 0;

    /** @brief Prints the component's current operational state. */
    virtual void reportStatus() const = 0;

    /** @brief Returns the attendee capacity represented by this component. */
    virtual int getCapacity() const = 0;
    
    /** @brief Returns a stable human-readable name. */
    virtual const std::string& getName() const = 0;
};

#endif
