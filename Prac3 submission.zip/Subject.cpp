#include "Subject.h"
#include <algorithm>

Subject::~Subject() {
    // Subjects do not own observers. Tell each observer to remove this dead subject.
    std::vector<Observer*> copy = observers_;
    for (std::vector<Observer*>::iterator it = copy.begin(); it != copy.end(); ++it) {
        if (*it) {
            (*it)->subjectDestroyed(this);
        }
    }
    observers_.clear();
}

void Subject::attach(Observer* observer) {
    if (!observer) return;
    if (std::find(observers_.begin(), observers_.end(), observer) == observers_.end()) {
        observers_.push_back(observer);
        observer->rememberSubject(this);
    }
}

void Subject::detach(Observer* observer) {
    if (!observer) return;
    std::vector<Observer*>::iterator it = std::find(observers_.begin(), observers_.end(), observer);
    if (it != observers_.end()) {
        observers_.erase(it);
        observer->forgetSubject(this);
    }
}

std::vector<Observer*> Subject::observerSnapshot() const {
    return observers_;
}
