#include "EventControl.h"
#include "EventGroup.h"
#include <iostream>
#include <vector>

EventControl::EventControl() : currentNotice_(nullptr) {}

EventControl::~EventControl() {
    delete currentNotice_;
    currentNotice_ = nullptr;
}

void EventControl::issueNotice(const Notice& notice) {
    delete currentNotice_;
    currentNotice_ = new Notice(notice);
    std::cout << "\n[CONTROL] Publishing " << noticeTypeToString(notice.type)
              << ": " << notice.message << "\n";
    notify();
}

bool EventControl::evaluateCapacity(EventGroup* group, int threshold) {
    if (!group) return false;
    const int capacity = group->getCapacity();
    std::cout << "[CONTROL] Capacity check for " << group->getName()
              << " = " << capacity << " against threshold " << threshold << ".\n";
    if (group->capacityAtLeast(threshold)) {
        issueNotice(Notice(NoticeType::CAPACITY_ALERT,
                           "Aggregate capacity threshold reached in " + group->getName(),
                           capacity));
        if (capacity >= static_cast<int>(threshold * 0.9)) {
            issueNotice(Notice(NoticeType::PAUSE,
                               "High crowd pressure: temporarily pause non-essential demonstrations",
                               capacity));
        }
        return true;
    }
    return false;
}

void EventControl::notify() {
    std::vector<Observer*> snapshot = observerSnapshot();
    for (std::vector<Observer*>::iterator it = snapshot.begin(); it != snapshot.end(); ++it) {
        if (*it) (*it)->update(*currentNotice_);
    }
}

const Notice* EventControl::currentNotice() const { return currentNotice_; }
