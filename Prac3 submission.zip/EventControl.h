#ifndef EVENTCONTROL_H
#define EVENTCONTROL_H

#include <string>
#include "Subject.h"
#include "Notice.h"

class EventGroup;

/**
 * @brief Concrete Subject acting as the central event control centre.
 *
 * It publishes event-wide notices but owns neither observers nor Composite
 * components. This keeps coordination separate from the Composite ownership tree.
 */
class EventControl : public Subject {
public:
    /** @brief Constructs an event control centre with no current notice. */
    EventControl();
    /** @brief Destroys the subject without deleting observers. */
    virtual ~EventControl();

    /**
     * @brief Publishes a push notification to current observers.
     * @param notice Notice to store and publish.
     */
    void issueNotice(const Notice& notice);

    /**
     * @brief Evaluates a Composite capacity and optionally publishes a warning.
     * @param group Group whose aggregate capacity is checked.
     * @param threshold Capacity threshold for the warning.
     * @return true when capacity is at least the threshold and a warning is issued.
     * @note At 90% of the threshold the control centre also publishes a PAUSE notice
     *       to demonstrate a high-pressure operational response.
     */
    bool evaluateCapacity(EventGroup* group, int threshold);

    /** @brief Notifies a snapshot of currently registered observers. */
    virtual void notify();

    /** @brief Returns the last notice, or nullptr before the first notice. */
    const Notice* currentNotice() const;

private:
    Notice* currentNotice_;
};

#endif
