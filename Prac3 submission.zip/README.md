# EventFlow — Pretoria Innovation Expo 2026

COS 214 Practical 3 implementation in C++11.

## Event concept

Pretoria Innovation Expo is a technology exhibition with nested operational areas. The Composite tree is:

```text
Pretoria Innovation Expo
├── Tech Hall
│   ├── Future Mobility Zone
│   │   ├── Keynote Stage
│   │   └── Robotics Demo Booth
│   ├── Digital Futures Zone
│   │   ├── AI Lab Booth
│   │   └── Visitor Information Desk
│   └── Future Bites Vendor   <- moved here at runtime
└── Community Hall
    ├── Innovation Shuttle Stop
    └── Tech Hall Security
```

The design intentionally separates **ownership** (Composite child pointers) from **observation** (non-owning Subject/Observer registrations).

## Build and run

```bash
make
./eventflow
```

The Makefile builds with `-std=c++11` and creates an executable named `eventflow`.

## Doxygen

```bash
doxygen Doxyfile
```

Generated HTML documentation appears in `docs/doxygen/html`.

## Architecture

- `EventComponent`: common Composite Component interface.
- `EventGroup`: Composite node; also Observer and Subject so notices can cascade through the tree.
- `EventUnit`: Composite Leaf base; concrete leaves implement polymorphic reactions.
- `EventControl`: concrete Observer Subject that publishes event-wide notices.
- `Subject`: non-owning observer registration list. Duplicate attach is ignored; missing detach is a no-op.
- `Observer`: maintains non-owning back-references so destruction unregisters safely.
- `Notice`: pushed event state.

### Observer choice: Push

EventFlow uses push. `Subject::notify()` passes a `const Notice&` directly into `Observer::update(const Notice&)`. This makes each notification self-contained and avoids observers querying a subject for a second time. The trade-off is that the notice structure must contain the information observers may need.

### Ownership

A Composite owns its children. `add()` transfers ownership to the group and `remove()` transfers ownership back to the caller. Observer registrations are non-owning. During observer destruction the observer unregisters from all live subjects; during subject destruction observers are informed that the subject is gone. This avoids dangling registration pointers.

### Registration during notification

Subjects notify a snapshot of their observer list. Therefore a detach/attach performed by an observer while notification is in progress affects subsequent notifications rather than invalidating the current iteration.

## Required scenarios demonstrated by `main.cpp`

1. Composite construction with more than three nesting levels.
2. Observer registration, including duplicate registration policy.
3. Schedule-change cascade.
4. Weather alert with polymorphic reactions.
5. Capacity threshold decision.
6. Transport delay.
7. Runtime vendor transfer between Composite parents plus observer detach/attach.
8. Observer leaving and later rejoining.
9. Evacuation and recovery.
10. Stock alert original feature.
11. Composite traversal/capacity query.
12. Root deletion and clean shutdown.

## Sequence diagrams

PlantUML sources are in `docs/`:

- `SD1_build_register.puml`
- `SD2_cascading_notification.puml`
- `SD3_conditional_capacity.puml`
- `SD4_signature_safety_recovery.puml`
- `object_diagram.puml`

They use object-instance lifelines, real method names/signatures, loop/alt/opt fragments and nested calls.


## Team details


- Member 1: Boikemelo Masoka u25128648
- Member 2: Boitumelo Monareng u25208943
- Member 3: Terrence Hluyo u25446968

Also replace the GitHub repository placeholder in the final report.
