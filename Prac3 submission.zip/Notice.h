#ifndef NOTICE_H
#define NOTICE_H

#include <string>

enum class NoticeType {
    OPEN,
    CLOSE,
    SCHEDULE_CHANGE,
    CAPACITY_ALERT,
    WEATHER_ALERT,
    TRANSPORT_DELAY,
    EVACUATE,
    PAUSE,
    RESUME,
    STOCK_ALERT
};

/**
 * @brief Immutable information pushed from a Subject to its Observers.
 *
 * EventFlow deliberately uses the push model: observers receive the exact
 * notice data needed to react, rather than querying a subject after update().
 */
struct Notice {
    NoticeType type;
    std::string message;
    int value;

    Notice(NoticeType t, const std::string& m, int v = 0)
        : type(t), message(m), value(v) {}
};

/** @brief Converts a notice type to readable text for the demonstration. */
inline std::string noticeTypeToString(NoticeType type) {
    switch (type) {
        case NoticeType::OPEN: return "OPEN";
        case NoticeType::CLOSE: return "CLOSE";
        case NoticeType::SCHEDULE_CHANGE: return "SCHEDULE_CHANGE";
        case NoticeType::CAPACITY_ALERT: return "CAPACITY_ALERT";
        case NoticeType::WEATHER_ALERT: return "WEATHER_ALERT";
        case NoticeType::TRANSPORT_DELAY: return "TRANSPORT_DELAY";
        case NoticeType::EVACUATE: return "EVACUATE";
        case NoticeType::PAUSE: return "PAUSE";
        case NoticeType::RESUME: return "RESUME";
        case NoticeType::STOCK_ALERT: return "STOCK_ALERT";
    }
    return "UNKNOWN";
}

#endif
