#ifndef EVENTGROUP_H
#define EVENTGROUP_H

#include <string>
#include <vector>
#include "EventComponent.h"
#include "Subject.h"
#include "Observer.h"

/**
 * @brief Composite node representing a venue, hall, zone or other area.
 *
 * GoF Composite Composite role and, simultaneously, Observer/Subject roles.
 * It owns child EventComponents but never owns its observers. A received
 * notice is re-published to interested objects below this group.
 */
class EventGroup : public EventComponent, public Subject, public Observer {
public:
    /**
     * @brief Constructs an empty event group.
     * @param name Human-readable group name.
     */
    explicit EventGroup(const std::string& name);

    /** @brief Destroys the group and its entire owned subtree exactly once. */
    virtual ~EventGroup();

    /** @brief Opens this group and all owned descendants. */
    virtual void open();
    /** @brief Closes this group and all owned descendants. */
    virtual void close();
    /** @brief Reports this group's state and aggregate capacity. */
    virtual void reportStatus() const;
    /** @brief Returns the sum of capacities of all descendants. */
    virtual int getCapacity() const;
    /** @brief Returns this group's name. */
    virtual const std::string& getName() const;

    /**
     * @brief Adds and takes ownership of a child component.
     * @param child Heap-allocated component transferred to this group.
     * @return true when accepted; false for nullptr or an already-owned pointer.
     * @note After a successful add(), the caller must not delete child.
     */
    bool add(EventComponent* child);

    /**
     * @brief Removes a direct child and transfers ownership to the caller.
     * @param childName Name of the direct child to remove.
     * @return The removed component, or nullptr when not found.
     * @note The caller becomes responsible for deleting or re-adding the returned object.
     */
    EventComponent* remove(const std::string& childName);

    /**
     * @brief Finds a direct child by name.
     * @param childName Name to find.
     * @return Non-owning pointer to the child, or nullptr if absent.
     */
    EventComponent* findChild(const std::string& childName) const;

    /** @brief Returns the number of direct children. */
    std::size_t childCount() const;

    /**
     * @brief Receives a pushed notice from an upstream Subject and cascades it.
     * @param notice Notice being propagated.
     */
    virtual void update(const Notice& notice);

    /** @brief Notifies the currently registered observers of currentNotice_. */
    virtual void notify();

    /**
     * @brief Tests aggregate capacity against a threshold.
     * @param threshold Capacity at which a warning is required.
     * @return true when aggregate capacity is greater than or equal to threshold.
     */
    bool capacityAtLeast(int threshold) const;

    /** @brief Returns the most recently received notice, if any. */
    const Notice* currentNotice() const;

private:
    std::string name_;
    std::vector<EventComponent*> children_; ///< Owning child pointers.
    bool open_;
    Notice* currentNotice_; ///< Owned copy of the last pushed notice, if any.
};

#endif
