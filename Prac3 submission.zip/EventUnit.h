#ifndef EVENTUNIT_H
#define EVENTUNIT_H

#include <string>
#include "EventComponent.h"
#include "Observer.h"

/**
 * @brief Common base for operational leaf objects.
 *
 * GoF Composite Leaf role and an Observer because operational units react to
 * notices from their containing event area.
 */
class EventUnit : public EventComponent, public Observer {
public:
    /**
     * @brief Constructs an operational unit.
     * @param name Unit name.
     * @param capacity Attendee capacity represented by the unit.
     */
    EventUnit(const std::string& name, int capacity);
    /** @brief Virtual destructor for polymorphic destruction. */
    virtual ~EventUnit();

    /** @brief Opens the unit for operation. */
    virtual void open();
    /** @brief Closes the unit. */
    virtual void close();
    /** @brief Reports unit-specific state. */
    virtual void reportStatus() const;
    /** @brief Returns the unit capacity. */
    virtual int getCapacity() const;
    /** @brief Returns the unit name. */
    virtual const std::string& getName() const;

    /**
     * @brief Reacts to a notice according to the concrete unit's policy.
     * @param notice Pushed event notice.
     */
    virtual void update(const Notice& notice) = 0;

protected:
    std::string name_;
    int capacity_;
    bool active_;
    std::string state_;

    /** @brief Changes the state string and prints a unit action. */
    void setState(const std::string& state, const std::string& action);
};

/** @brief Outdoor keynote stage that pauses for weather and supports schedule changes. */
class DemoStage : public EventUnit {
public:
    /** @param name Stage name. @param capacity Stage capacity. */
    explicit DemoStage(const std::string& name, int capacity = 500);
    virtual ~DemoStage() {}
    /** @param notice Notice to process. */
    virtual void update(const Notice& notice);
};

/** @brief Interactive technology booth that limits queues under capacity pressure. */
class InnovationBooth : public EventUnit {
public:
    /** @param name Booth name. @param capacity Booth capacity. */

    explicit InnovationBooth(const std::string& name, int capacity = 80);
    virtual ~InnovationBooth() {}

    /** @param notice Notice to process. */
    
    virtual void update(const Notice& notice);
};

/** @brief Visitor information service that keeps guidance active during emergencies. */
class InformationDesk : public EventUnit {
public:
    /** @param name Desk name. @param capacity Desk capacity. */
    explicit InformationDesk(const std::string& name, int capacity = 20);
    virtual ~InformationDesk() {}
    /** @param notice Notice to process. */
    virtual void update(const Notice& notice);
};

/** @brief Transport unit that reacts specifically to shuttle delays and evacuation support. */
class ShuttleStop : public EventUnit {
public:
    /** @param name Stop name. @param capacity Stop capacity. */
    explicit ShuttleStop(const std::string& name, int capacity = 120);
    virtual ~ShuttleStop() {}
    /** @param notice Notice to process. */
    virtual void update(const Notice& notice);
};

/** @brief Security unit that increases crowd-control readiness for safety notices. */
class SecurityTeam : public EventUnit {
public:
    /** @param name Team name. @param capacity Nominal team capacity. */
    explicit SecurityTeam(const std::string& name, int capacity = 10);
    virtual ~SecurityTeam() {}
    /** @param notice Notice to process. */
    virtual void update(const Notice& notice);
};

/** @brief Food service unit that reacts to stock and crowd-capacity notices. */
class FoodVendor : public EventUnit {
public:
    /** @param name Vendor name. @param capacity Vendor capacity. */
    explicit FoodVendor(const std::string& name, int capacity = 60);
    virtual ~FoodVendor() {}
    /** @param notice Notice to process. */
    virtual void update(const Notice& notice);
};

#endif
