#include "Observer.h"
#include "Subject.h"
#include <algorithm>

Observer::~Observer() {
    // Observers do not own subjects. Unregister from every live subject.
    std::vector<Subject*> copy = subjects_;
    for (std::vector<Subject*>::iterator it = copy.begin(); it != copy.end(); ++it) {
        if (*it) {
            (*it)->detach(this);
        }
    }
}

void Observer::rememberSubject(Subject* subject) {
    if (!subject) return;
    if (std::find(subjects_.begin(), subjects_.end(), subject) == subjects_.end()) {
        subjects_.push_back(subject);
    }
}

void Observer::forgetSubject(Subject* subject) {
    subjects_.erase(std::remove(subjects_.begin(), subjects_.end(), subject), subjects_.end());
}

void Observer::subjectDestroyed(Subject* subject) {
    forgetSubject(subject);
}
