#ifndef SUBJECT_H
#define SUBJECT_H

#include <vector>
#include "Observer.h"

/**
 * @brief Subject abstraction for the Gang of Four Observer pattern.
 *
 * Observer pointers are non-owning. Duplicate registrations are ignored and
 * detaching an unregistered observer is a no-op.
 */
class Subject {
public:
    virtual ~Subject();

    /**
     * @brief Registers an observer once.
     * @param observer Non-owning observer pointer; nullptr is ignored.
     */
    virtual void attach(Observer* observer);

    /**
     * @brief Removes an observer if currently registered.
     * @param observer Non-owning observer pointer; missing observers are ignored.
     */
    virtual void detach(Observer* observer);

    /** @brief Notifies a snapshot of currently registered observers. */
    virtual void notify() = 0;

protected:
    std::vector<Observer*> observers_; ///< Non-owning observer registrations.

    /** @brief Returns a copy so registration changes during notification are safe. */
    std::vector<Observer*> observerSnapshot() const;
};

#endif
