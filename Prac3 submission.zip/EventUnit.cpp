#include "EventUnit.h"
#include <iostream>

EventUnit::EventUnit(const std::string& name, int capacity)
    : name_(name), capacity_(capacity), active_(false), state_("CLOSED") {}

EventUnit::~EventUnit() {}

void EventUnit::open() {
    active_ = true;
    state_ = "OPEN";
    std::cout << "[UNIT] " << name_ << " opened.\n";
}

void EventUnit::close() {
    active_ = false;
    state_ = "CLOSED";
    std::cout << "[UNIT] " << name_ << " closed.\n";
}

void EventUnit::reportStatus() const {
    std::cout << "[STATUS] Unit: " << name_ << " | state=" << state_
              << " | capacity=" << capacity_ << "\n";
}

int EventUnit::getCapacity() const { return capacity_; }
const std::string& EventUnit::getName() const { return name_; }

void EventUnit::setState(const std::string& state, const std::string& action) {
    state_ = state;
    std::cout << "[REACTION] " << name_ << " -> " << action << " (" << state_ << ")\n";
}

DemoStage::DemoStage(const std::string& name, int capacity) : EventUnit(name, capacity) {}
void DemoStage::update(const Notice& notice) {
    switch (notice.type) {
        case NoticeType::WEATHER_ALERT:
            setState("PAUSED", "outdoor performance paused for weather"); break;
        case NoticeType::PAUSE:
            setState("PAUSED", "performance paused"); break;
        case NoticeType::RESUME:
            setState("OPEN", "performance resumed"); break;
        case NoticeType::SCHEDULE_CHANGE:
            setState(state_, "loaded the new performance schedule"); break;
        case NoticeType::EVACUATE:
            setState("EVACUATING", "clearing performers and audience"); break;
        case NoticeType::OPEN:
            open(); break;
        case NoticeType::CLOSE:
            close(); break;
        default:
            std::cout << "[REACTION] " << name_ << " -> acknowledged " << noticeTypeToString(notice.type) << ".\n";
    }
}

InnovationBooth::InnovationBooth(const std::string& name, int capacity) : EventUnit(name, capacity) {}
void InnovationBooth::update(const Notice& notice) {
    switch (notice.type) {
        case NoticeType::CAPACITY_ALERT:
            setState("LIMITED", "reduced demo queue intake due to capacity pressure"); break;
        case NoticeType::EVACUATE:
            setState("EVACUATING", "secured equipment and evacuated visitors"); break;
        case NoticeType::SCHEDULE_CHANGE:
            setState(state_, "updated its demo timetable"); break;
        case NoticeType::OPEN:
            open(); break;
        case NoticeType::CLOSE:
            close(); break;
        default:
            std::cout << "[REACTION] " << name_ << " -> acknowledged " << noticeTypeToString(notice.type) << ".\n";
    }
}

InformationDesk::InformationDesk(const std::string& name, int capacity) : EventUnit(name, capacity) {}
void InformationDesk::update(const Notice& notice) {
    switch (notice.type) {
        case NoticeType::SCHEDULE_CHANGE:
            setState("OPEN", "updated visitor information screens"); break;
        case NoticeType::EVACUATE:
            setState("OPEN", "switched to evacuation guidance mode"); break;
        case NoticeType::WEATHER_ALERT:
            setState("OPEN", "broadcast weather guidance to attendees"); break;
        case NoticeType::OPEN:
            open(); break;
        case NoticeType::CLOSE:
            close(); break;
        default:
            std::cout << "[REACTION] " << name_ << " -> acknowledged " << noticeTypeToString(notice.type) << ".\n";
    }
}

ShuttleStop::ShuttleStop(const std::string& name, int capacity) : EventUnit(name, capacity) {}
void ShuttleStop::update(const Notice& notice) {
    switch (notice.type) {
        case NoticeType::TRANSPORT_DELAY:
            setState("DELAYED", "changed pickup messaging and dispatch expectation"); break;
        case NoticeType::EVACUATE:
            setState("EVACUATION_ROUTE", "reserved transport for evacuation support"); break;
        case NoticeType::OPEN:
            open(); break;
        case NoticeType::CLOSE:
            close(); break;
        default:
            std::cout << "[REACTION] " << name_ << " -> acknowledged " << noticeTypeToString(notice.type) << ".\n";
    }
}

SecurityTeam::SecurityTeam(const std::string& name, int capacity) : EventUnit(name, capacity) {}
void SecurityTeam::update(const Notice& notice) {
    switch (notice.type) {
        case NoticeType::CAPACITY_ALERT:
            setState("HIGH_ALERT", "increased crowd-control presence"); break;
        case NoticeType::EVACUATE:
            setState("DEPLOYED", "activated evacuation perimeter"); break;
        case NoticeType::WEATHER_ALERT:
            setState("ACTIVE", "moved to weather-risk monitoring points"); break;
        case NoticeType::OPEN:
            setState("ACTIVE", "started security coverage"); break;
        case NoticeType::CLOSE:
            setState("STANDBY", "entered post-event standby"); break;
        default:
            std::cout << "[REACTION] " << name_ << " -> acknowledged " << noticeTypeToString(notice.type) << ".\n";
    }
}

FoodVendor::FoodVendor(const std::string& name, int capacity) : EventUnit(name, capacity) {}
void FoodVendor::update(const Notice& notice) {
    switch (notice.type) {
        case NoticeType::STOCK_ALERT:
            setState("LIMITED_MENU", "switched to stock-conserving menu"); break;
        case NoticeType::CAPACITY_ALERT:
            setState("QUEUE_CONTROL", "limited new orders to reduce crowding"); break;
        case NoticeType::EVACUATE:
            setState("CLOSED_SAFE", "secured cooking equipment before evacuation"); break;
        case NoticeType::OPEN:
            open(); break;
        case NoticeType::CLOSE:
            close(); break;
        default:
            std::cout << "[REACTION] " << name_ << " -> acknowledged " << noticeTypeToString(notice.type) << ".\n";
    }
}
