#include "EventGroup.h"
#include <iostream>
#include <algorithm>

EventGroup::EventGroup(const std::string& name)
    : name_(name), children_(), open_(false), currentNotice_(nullptr) {}

EventGroup::~EventGroup() {
    delete currentNotice_;
    currentNotice_ = nullptr;
    for (std::vector<EventComponent*>::iterator it = children_.begin(); it != children_.end(); ++it) {
        delete *it;
    }
    children_.clear();
}

void EventGroup::open() {
    open_ = true;
    std::cout << "[GROUP] " << name_ << " opened.\n";
    for (std::vector<EventComponent*>::iterator it = children_.begin(); it != children_.end(); ++it) {
        (*it)->open();
    }
}

void EventGroup::close() {
    open_ = false;
    std::cout << "[GROUP] " << name_ << " closed.\n";
    for (std::vector<EventComponent*>::iterator it = children_.begin(); it != children_.end(); ++it) {
        (*it)->close();
    }
}

void EventGroup::reportStatus() const {
    std::cout << "[STATUS] Group: " << name_
              << " | state=" << (open_ ? "OPEN" : "CLOSED")
              << " | capacity=" << getCapacity()
              << " | children=" << children_.size() << "\n";
    for (std::vector<EventComponent*>::const_iterator it = children_.begin(); it != children_.end(); ++it) {
        (*it)->reportStatus();
    }
}

int EventGroup::getCapacity() const {
    int total = 0;
    for (std::vector<EventComponent*>::const_iterator it = children_.begin(); it != children_.end(); ++it) {
        total += (*it)->getCapacity();
    }
    return total;
}

const std::string& EventGroup::getName() const { return name_; }

bool EventGroup::add(EventComponent* child) {
    if (!child) return false;
    if (std::find(children_.begin(), children_.end(), child) != children_.end()) return false;
    children_.push_back(child);
    std::cout << "[COMPOSITE] " << child->getName() << " added to " << name_ << ".\n";
    return true;
}

EventComponent* EventGroup::remove(const std::string& childName) {
    for (std::vector<EventComponent*>::iterator it = children_.begin(); it != children_.end(); ++it) {
        if ((*it)->getName() == childName) {
            EventComponent* child = *it;
            children_.erase(it);
            std::cout << "[COMPOSITE] " << childName << " removed from " << name_ << ".\n";
            return child;
        }
    }
    return nullptr;
}

EventComponent* EventGroup::findChild(const std::string& childName) const {
    for (std::vector<EventComponent*>::const_iterator it = children_.begin(); it != children_.end(); ++it) {
        if ((*it)->getName() == childName) return *it;
    }
    return nullptr;
}

std::size_t EventGroup::childCount() const { return children_.size(); }

void EventGroup::update(const Notice& notice) {
    delete currentNotice_;
    currentNotice_ = new Notice(notice);
    std::cout << "[OBSERVER] Group " << name_ << " received "
              << noticeTypeToString(notice.type) << ": " << notice.message << "\n";
    notify();
}

void EventGroup::notify() {
    std::vector<Observer*> snapshot = observerSnapshot();
    for (std::vector<Observer*>::iterator it = snapshot.begin(); it != snapshot.end(); ++it) {
        if (*it) (*it)->update(*currentNotice_);
    }
}

bool EventGroup::capacityAtLeast(int threshold) const {
    return getCapacity() >= threshold;
}

const Notice* EventGroup::currentNotice() const { return currentNotice_; }
