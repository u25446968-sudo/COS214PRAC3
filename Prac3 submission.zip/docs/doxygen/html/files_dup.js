var files_dup =
[
    [ "EventComponent.h", "_event_component_8h.html", "_event_component_8h" ],
    [ "EventControl.cpp", "_event_control_8cpp.html", null ],
    [ "EventControl.h", "_event_control_8h.html", "_event_control_8h" ],
    [ "EventGroup.cpp", "_event_group_8cpp.html", null ],
    [ "EventGroup.h", "_event_group_8h.html", "_event_group_8h" ],
    [ "EventUnit.cpp", "_event_unit_8cpp.html", null ],
    [ "EventUnit.h", "_event_unit_8h.html", "_event_unit_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Notice.h", "_notice_8h.html", "_notice_8h" ],
    [ "Observer.cpp", "_observer_8cpp.html", null ],
    [ "Observer.h", "_observer_8h.html", "_observer_8h" ],
    [ "Subject.cpp", "_subject_8cpp.html", null ],
    [ "Subject.h", "_subject_8h.html", "_subject_8h" ]
];