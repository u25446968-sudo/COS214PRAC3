var class_subject =
[
    [ "~Subject", "class_subject.html#a7c4f522850f718466e5be7eb55ba1969", null ],
    [ "attach", "class_subject.html#a0884bfe374d352c6488a1e40c84246c8", null ],
    [ "detach", "class_subject.html#a752a7596d52ab986539232f8377ca92c", null ],
    [ "notify", "class_subject.html#aedd8aa6de28b18ef5880566de4294bfe", null ],
    [ "observerSnapshot", "class_subject.html#acc468e7e9c9a96a58715d1fe197ae84c", null ],
    [ "observers_", "class_subject.html#a862ab5ebcc13c62ef2a48b3cbf2abf88", null ]
];