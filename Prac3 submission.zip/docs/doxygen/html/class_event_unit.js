var class_event_unit =
[
    [ "EventUnit", "class_event_unit.html#ae397204f000c380aa170bf9ed467baa9", null ],
    [ "~EventUnit", "class_event_unit.html#a1e6fc3a03c85f7e21f8ed6865de99974", null ],
    [ "close", "class_event_unit.html#ad4dfb17137ec1862dce733bed6437643", null ],
    [ "getCapacity", "class_event_unit.html#a11a3694ddaee3c117853bb56bd7b7ee9", null ],
    [ "getName", "class_event_unit.html#a54c1d6084e371dea473b34327ed1831b", null ],
    [ "open", "class_event_unit.html#a8378540f9e4cf375bae386f6598979b9", null ],
    [ "reportStatus", "class_event_unit.html#a36766cad3d7039e8ec545257a085aa35", null ],
    [ "setState", "class_event_unit.html#a39d09261919fdba77c362c380efc2c11", null ],
    [ "update", "class_event_unit.html#afb2e115ae6f8b0917c1023b637e531f0", null ],
    [ "active_", "class_event_unit.html#a7d8c2337e7efb2052764289b1f1fc915", null ],
    [ "capacity_", "class_event_unit.html#ae8d8de453f6ed278be9a936ffc6994c6", null ],
    [ "name_", "class_event_unit.html#ad33befc8de443e73a76721bab4a52372", null ],
    [ "state_", "class_event_unit.html#ad5acee2b8fc3e62450e3884e04bb2dc7", null ]
];