var class_observer =
[
    [ "~Observer", "class_observer.html#a450645e61c136826f09940a1334c7f34", null ],
    [ "forgetSubject", "class_observer.html#a93ab86a4c0d759d72130972ca4dd01c6", null ],
    [ "rememberSubject", "class_observer.html#abb1cb9c16634287a65086237cb43cd92", null ],
    [ "subjectDestroyed", "class_observer.html#ab4fbca52604d403008bd57932b0311e2", null ],
    [ "update", "class_observer.html#a1facbbd0e34f6034d183ae9bcabbf1b0", null ]
];