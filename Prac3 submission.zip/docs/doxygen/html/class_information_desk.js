var class_information_desk =
[
    [ "InformationDesk", "class_information_desk.html#a906d0fdc6f0e98e60d8b117c699cbddb", null ],
    [ "~InformationDesk", "class_information_desk.html#acc0afc01019bee2a7801dd504b96af6b", null ],
    [ "update", "class_information_desk.html#ae494cc0ffdd5775b69603eb6baa6f4c7", null ]
];