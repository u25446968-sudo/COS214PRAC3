var annotated_dup =
[
    [ "DemoStage", "class_demo_stage.html", "class_demo_stage" ],
    [ "EventComponent", "class_event_component.html", "class_event_component" ],
    [ "EventControl", "class_event_control.html", "class_event_control" ],
    [ "EventGroup", "class_event_group.html", "class_event_group" ],
    [ "EventUnit", "class_event_unit.html", "class_event_unit" ],
    [ "FoodVendor", "class_food_vendor.html", "class_food_vendor" ],
    [ "InformationDesk", "class_information_desk.html", "class_information_desk" ],
    [ "InnovationBooth", "class_innovation_booth.html", "class_innovation_booth" ],
    [ "Notice", "struct_notice.html", "struct_notice" ],
    [ "Observer", "class_observer.html", "class_observer" ],
    [ "SecurityTeam", "class_security_team.html", "class_security_team" ],
    [ "ShuttleStop", "class_shuttle_stop.html", "class_shuttle_stop" ],
    [ "Subject", "class_subject.html", "class_subject" ]
];