var searchData=
[
  ['transport_5fdelay_0',['TRANSPORT_DELAY',['../_notice_8h.html#af363a9693a3fb910ac7c54199a89c570abd39d60280f46973f8eb26615efec443',1,'Notice.h']]],
  ['type_1',['type',['../struct_notice.html#ae2f875d6153cefbd8baaadcf4d6cdc88',1,'Notice']]]
];
