var searchData=
[
  ['value_0',['value',['../struct_notice.html#a8fdef316298065da4a18c7bc9f9c8f34',1,'Notice']]]
];
