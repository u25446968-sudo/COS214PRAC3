var searchData=
[
  ['main_0',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['main_2ecpp_1',['main.cpp',['../main_8cpp.html',1,'']]],
  ['message_2',['message',['../struct_notice.html#ad07e4c63f849c0c960addcd2fd2276a2',1,'Notice']]]
];
