var indexSectionsWithContent =
{
  0: "acdefgimnoprstuvw~",
  1: "definos",
  2: "emnos",
  3: "acdefgimnorsu~",
  4: "acmnostv",
  5: "n",
  6: "ceoprstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

