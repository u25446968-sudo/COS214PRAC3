var class_shuttle_stop =
[
    [ "ShuttleStop", "class_shuttle_stop.html#a34e557628f343a07fdcfcd4297d7caf1", null ],
    [ "~ShuttleStop", "class_shuttle_stop.html#a7458f6fd2e7792cd4c37d3065cd92aa4", null ],
    [ "update", "class_shuttle_stop.html#ad7685669c8ef8f2b018c6135c8fa3efa", null ]
];