var struct_notice =
[
    [ "Notice", "struct_notice.html#a915338b792eb5dd760cb4db014cc8334", null ],
    [ "message", "struct_notice.html#ad07e4c63f849c0c960addcd2fd2276a2", null ],
    [ "type", "struct_notice.html#ae2f875d6153cefbd8baaadcf4d6cdc88", null ],
    [ "value", "struct_notice.html#a8fdef316298065da4a18c7bc9f9c8f34", null ]
];