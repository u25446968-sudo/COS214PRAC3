var hierarchy =
[
    [ "EventComponent", "class_event_component.html", [
      [ "EventGroup", "class_event_group.html", null ],
      [ "EventUnit", "class_event_unit.html", [
        [ "DemoStage", "class_demo_stage.html", null ],
        [ "FoodVendor", "class_food_vendor.html", null ],
        [ "InformationDesk", "class_information_desk.html", null ],
        [ "InnovationBooth", "class_innovation_booth.html", null ],
        [ "SecurityTeam", "class_security_team.html", null ],
        [ "ShuttleStop", "class_shuttle_stop.html", null ]
      ] ]
    ] ],
    [ "Notice", "struct_notice.html", null ],
    [ "Observer", "class_observer.html", [
      [ "EventGroup", "class_event_group.html", null ],
      [ "EventUnit", "class_event_unit.html", null ]
    ] ],
    [ "Subject", "class_subject.html", [
      [ "EventControl", "class_event_control.html", null ],
      [ "EventGroup", "class_event_group.html", null ]
    ] ]
];