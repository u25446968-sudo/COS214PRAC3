var class_event_control =
[
    [ "EventControl", "class_event_control.html#ae7506622df5596f7385e23ca8e640a5c", null ],
    [ "~EventControl", "class_event_control.html#ad8fcc15169bd6829ac92497adf216b94", null ],
    [ "currentNotice", "class_event_control.html#a637cef7826951a9d9b7fbcd5ea013b52", null ],
    [ "evaluateCapacity", "class_event_control.html#a2af2762bffacd1ee7c5fb06a54e3ac36", null ],
    [ "issueNotice", "class_event_control.html#ac21db8f4791c306a2b214309b4e400e6", null ],
    [ "notify", "class_event_control.html#a0ecbabbbb91300a1cd00627b2c7ed2b3", null ]
];