#ifndef OBSERVER_H
#define OBSERVER_H

#include <vector>
#include "Notice.h"

class Subject;

/**
 * @brief Observer abstraction for objects interested in event notices.
 *
 * The Observer keeps non-owning back-references to Subjects so its destructor
 * can safely unregister itself. Subjects are never owned by an Observer.
 */
class Observer {
public:
    virtual ~Observer();

    /**
     * @brief Reacts to a pushed event notice.
     * @param notice Notice containing the changed event state.
     */
    virtual void update(const Notice& notice) = 0;

    /** @brief Records a subject that registered this observer. */
    void rememberSubject(Subject* subject);
    /** @brief Removes a subject from the observer's back-reference list. */
    void forgetSubject(Subject* subject);
    /** @brief Removes all subject references without invoking callbacks. */
    void subjectDestroyed(Subject* subject);

private:
    std::vector<Subject*> subjects_; ///< Non-owning registration back-references.
};

#endif
